// cypress/e2e/OrangeHRMglorya/Login/loginwithPOM.cy.js

import LoginPage from "../../pom/login/lastproject.cy";

describe('Testing Login Features', () => {
    beforeEach(() => {
        LoginPage.visit(); 
        cy.intercept('POST', 'https://opensource-demo.orangehrmlive.com/web/index.php/auth/validate').as('loginRequest');
    });

    it('Pengguna 1 login dengan username & password benar', () => {
        LoginPage.isLoginPageVisible().should('have.text', 'Login');
        LoginPage.inputUsername('Admin');
        LoginPage.inputPassword('admin123');
        LoginPage.buttonSubmit();

        cy.wait('@loginRequest').then((intercept) => {
            expect(intercept.response.statusCode).to.be.oneOf([200, 302]);
        });

        cy.url().should('include', '/dashboard');
    });

    it('Pengguna 1 tidak dapat login dnegan username benar', () => {
        LoginPage.isLoginPageVisible(); 
        LoginPage.inputUsername('Admin');
        LoginPage.inputPassword('wrongPassword');
        LoginPage.buttonSubmit();
    
        LoginPage.invalidCredentials().should('have.text', 'Invalid credentials');
    });

    it('Forgot Password 1', () => {
        LoginPage.clickForgotPassword(); 
        cy.url().should('include', '/auth/requestPasswordResetCode'); 
        LoginPage.inputUsername('Admin'); 
        LoginPage.submitForgotPassword();
    });

    it('Menu dashboard admin 1', () => {
        LoginPage.inputUsername('Admin');
        LoginPage.inputPassword('admin123');
        LoginPage.buttonSubmit();

        cy.wait('@loginRequest');
        cy.url().should('include', '/dashboard'); 
        cy.get('ul.oxd-main-menu').contains('Admin').click(); 
        cy.url().should('include', '/admin'); 
        cy.get('h6').contains('Admin').should('be.visible'); 
    });

});