/// <reference types="cypress" />


import LoginPage from "../../pom/login/login.cy";

describe('Fitur Login di OrangeHRM', () => {
    beforeEach(() => {
        LoginPage.visit();
    });

    context('Skenario Login Valid', () => {
        it('User dapat login dengan kredensial yang valid', () => {
            LoginPage.verifyLoginPage().should('have.text', 'Login');
            LoginPage.inputUsername('Admin');
            LoginPage.inputPassword('admin123');
            LoginPage.buttonSubmit();

            LoginPage.dashboardPage().should('have.text', 'Dashboard');
        });
    });

    context('Skenario Login Tidak Valid', () => {
        it('User tidak dapat login dengan username valid dan password tidak valid', () => {
            LoginPage.verifyLoginPage().should('have.text', 'Login');
            LoginPage.inputUsername('Admin');
            LoginPage.inputPassword('wrongPassword');
            LoginPage.buttonSubmit();

            LoginPage.invalidCredentials().should('have.text', 'Invalid credentials');
        });
    });
});
